//Crie uma classe Biblioteca que armazena um array de objetos do tipo Livro.
//Cada livro deve ter um título, autor e ano de publicação. 
//A biblioteca deve ter métodos para adicionar novos livros, 
//listar todos os livros e filtrar livros por ano de publicação


class Livro {
    titulo: string;
    autor: string;
    ano: number;

    constructor(titulo: string, autor: string, ano: number) {
        this.titulo = titulo;
        this.autor = autor;
        this.ano = ano;
    }
}

class Biblioteca {
    livros: Livro[];

    constructor(...livros: Livro[]) {
        this.livros = livros;
    }

    adicionarLivros(...novosLivros: Livro[]): void {
        this.livros = [...this.livros, ...novosLivros];
    }

    listarLivros(): void {
        this.livros.forEach(livro => {
            console.log(`${livro.titulo} por ${livro.autor} (Publicado em ${livro.ano})`);
        });
    }

    filtrarPorAno(ano: number): Livro[] {
        return this.livros.filter(livro => livro.ano === ano);
    }
}

// Teste da classe Biblioteca
const livro1 = new Livro("Dom Quixote", "Miguel de Cervantes", 1605);
const livro2 = new Livro("1984", "George Orwell", 1949);
const biblioteca = new Biblioteca(livro1);

biblioteca.adicionarLivros(livro2);
biblioteca.listarLivros();
// Saída: 
// Dom Quixote por Miguel de Cervantes (Publicado em 1605)
// 1984 por George Orwell (Publicado em 1949)

const livros1949 = biblioteca.filtrarPorAno(1949);
console.log(livros1949); // [Livro { titulo: '1984', autor: 'George Orwell', ano: 1949 }]



//Crie uma classe Calculadora com um método estático que possa somar,
//subtrair, multiplicar ou dividir uma lista de números utilizando o operador rest.


class Calculadora {
    static somar(...numeros: number[]): number {
        return numeros.reduce((acc, num) => acc + num, 0);
    }

    static multiplicar(...numeros: number[]): number {
        return numeros.reduce((acc, num) => acc * num, 1);
    }

    static subtrair(...numeros: number[]): number {
        return numeros.reduce((acc, num) => acc - num);
    }

    static dividir(...numeros: number[]): number {
        return numeros.reduce((acc, num) => acc / num);
    }
}

// Teste da classe Calculadora
console.log(Calculadora.somar(1, 2, 3, 4)); // Saída: 10
console.log(Calculadora.multiplicar(2, 3, 4)); // Saída: 24
console.log(Calculadora.subtrair(10, 2, 1)); // Saída: 7
console.log(Calculadora.dividir(100, 2, 5)); // Saída: 10
