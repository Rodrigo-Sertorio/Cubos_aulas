const usuario = {
	nome: 'Guido',
	email: 'guido@email.com',
	endereco: {
		rua: 'Rua A',
		numero: 123
	}
}

const { nome, email, endereco: { numero, rua } } = usuario

console.log(numero)
