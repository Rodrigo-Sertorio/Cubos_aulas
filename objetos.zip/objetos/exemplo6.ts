const pessoas = ['Rodrigo', 'Pedro', 'Thiago']

const [ nome1, nome2, nome3 ] = pessoas

console.log(nome2)