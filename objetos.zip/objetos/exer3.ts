// Crie um objeto que represente o cartão de consumo de um cliente. Deve ter:
// Nome do cliente
// Idade do cliente
// Produtos consumidos
// Cada produto pode ter:
// Nome do produto
// Preço unitário (em centavos)
// Quantidade comprada

// Pode inventar os dados. Coloque pelo menos 3 produtos.

type TProduto = {
	nome: string
	preco: number
	quantidade: number
}

type TCliente = {
	nome: string
	idade: number
	produtos: TProduto[]
}

const cartaoRodrigo: TCliente = {
	nome: 'Rodrigo',
	idade: 45,
	produtos: [
		{
			nome: 'Pizza de calabresa',
			preco: 9500,
			quantidade: 3
		},
		{
			nome: 'Refrigerante coca cola litro',
			preco: 998,
			quantidade: 2
		},
		{
			nome: 'trufa',
			preco: 1500,
			quantidade: 9
		}
	]
}

// console.log(cartaoRodrigo)

// Faça um programa que imprime uma mensagem amigável do resumo do cartão de consumo
// (que inclui chamar o cliente pelo nome) que informa o valor que ele deve pagar.

let total = 0

for (let produto of cartaoRodrigo.produtos) {
	total += produto.preco * produto.quantidade
}

console.log(`O total da compra do cliente ${cartaoRodrigo.nome} foi de ${total/100}`)