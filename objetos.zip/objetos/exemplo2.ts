// const usuarios = ['Guido', 'João', 'Maria']

const usuarios = [
	{
		nome: 'Rodrigo',
		email: 'rodrigo09.sertorio@email.com',
		idade: 33
	},
	{
		nome: 'Cardoso',
		email: 'rodrigo09.sertorio@live.com'
	},
	{
		nome: 'Sertorio',
		email: 'rodrigosertorio2008@hotmail.com'
	}
]

for (let usuario of usuarios) {
	console.log(`Nome: ${usuario.nome}, Email: ${usuario.email}`)
}