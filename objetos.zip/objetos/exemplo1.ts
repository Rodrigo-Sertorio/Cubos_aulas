const nome = 'Rodrigo'
const idade = 33
const temCNH = true

const usuario = { 
	nome: 'Rodrigo',
	idade: 45, 
	temCNH: true,
	habilidades: ['javascript', 'php', 'java', 'python']
}

// console.log(usuario)

// usuario['habilidades'] => acessa uma propriedade do objeto
// usuario.nome => acessa uma propriedade do objeto
// usuario['teste'] => retorna undefined pois a propriedade não foi definida

// usuario.nome = 'Rodrigo Sertorio'

usuario.email = 'rodrigo 09.sertorio@email.com'

console.log(`Meu nome é ${usuario.nome} e tenho ${usuario.idade} anos.`)