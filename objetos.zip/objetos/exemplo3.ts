const nome = 'Rodrigo'

const endereco = {
	rua: 'Rua Jose Barcelos Garcia',
	numero: '10',
	bairro: 'Rubem Berta',
    complemento: 'apto 307 BL D1'
}

// shorthand

const usuario = { 
	nome,
	idade: 45, 
	temCNH: true,
	habilidades: ['javascript', 'php', 'java', 'python'],
	endereco
}

console.log(usuario)