// type TCarro = {
// 	modelo: string
// 	marca: string
// 	ano: number
// 	cor?: string
// }

// const carro: TCarro = {
// 	modelo: 'Edge',
// 	marca: 'FORD',
// 	ano: 2013,
// 	cor: 'branco'
// }

// console.log(carro)

type TPessoa = {
	nome: string,
	senha: number
}

const fila = ['Rodrigo', 'Jonathan', 'Matheus', 'Pedro', 'Dani', 'Ariane']

const pessoas: TPessoa[] = []

for (let i = 0; i < fila.length; i++) {
	pessoas[i] = {
		nome: fila[i],
		senha: i + 1
	}
}

console.log(pessoas)