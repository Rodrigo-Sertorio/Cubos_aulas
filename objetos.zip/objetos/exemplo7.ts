// rest -> resto ou sobra
const pessoas = ['Rodrigo', 'Pedro', 'Dani']

const [ item1, ...novoArray ] = pessoas

const usuario = {
	nome: 'Rodrigo',
	email: 'rodrigo09.sertorio@email.com',
	idade: 34
}

const {idade, ...novoObjeto} = usuario

// console.log(idade)

// spread -> espalhamento

const carros = ['Pálio', 'Gol']

const novosCarros = [...carros, 'Ferrari', 'fusca']

const carro = {
	ano: 1990,
	cor: 'preto'
}

const informacoesCarro = {
	portas: 4,
	potencia: 100
}

const carroCompleto = {
	...carro,
	...informacoesCarro,
	marca: 'Ford',
	modelo: 'Ranger'
}

console.log(carroCompleto)