// Declare uma variável que armazena um objeto contendo as seguintes 
// propriedades: nome, idade, altura, temCNH e habilidades.

// Depois, faça um programa que imprime na tela o belo texto abaixo, 
// substituindo os dados pessoais pelos dados do objeto:

// Guido tem 33 anos, 1.87m de altura, possui CNH e as seguintes habilidades:
// - JavaScript
// - PHP
// - Python
// - Java

const usuario = {
	nome: 'Rodrig Sertorio',
	idade: 45,
	altura: 1.80,
	temCNH: true,
	habilidades: ['JavaScript', 'PHP', 'Python', 'Java', 'SQL']
}

const possuiCNH = usuario.temCNH ? 'possui CNH' : 'não possui CNH'

console.log(`${usuario.nome} tem ${usuario.idade} anos, ${usuario.altura}m de altura, ${possuiCNH} e as seguintes habilidades:`)
for (let item of usuario.habilidades) {
	console.log(`- ${item}`)
}