let numero1: number = 20
let numero2: number = 12

let resultado = numero1 + numero2

console.log(resultado)