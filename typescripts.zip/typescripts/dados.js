let nome = 'Rodrigo Sertorio' // string
//console.log(typeof nome)

let idade = 45 // number
//console.log(typeof idade)

let altura = 1.80 // number
//console.log(typeof altura)

let ativo = true // boolean
ativo = false // boolean
// console.log(typeof ativo)

let cor = 'Vermelho'
//console.log(typeof cor)

cor = null // tipo null ou object
//console.log(typeof cor)

let sobrenome // undefined
console.log(typeof sobrenome)

sobrenome = 'Sertorio'
console.log(typeof sobrenome)