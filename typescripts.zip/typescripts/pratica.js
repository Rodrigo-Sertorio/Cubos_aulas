var numero1 = 20;
var numero2 = 12;
var resultado = numero1 + numero2;
console.log(resultado);
