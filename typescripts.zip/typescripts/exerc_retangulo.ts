// Função para calcular a área de um retângulo
function calcularArea(largura: number, altura: number): number {
    return largura * altura;
}

// Variáveis de exemplo
let largura: number = 5;
let altura: number = 10;

// Calcular a área e mostrar no console
let area: number = calcularArea(largura, altura);
console.log(`A área do retângulo é: ${area}`);