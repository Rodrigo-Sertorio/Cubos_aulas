"use strict";
let nome = 'Rodrigo Cardoso';
console.log(nome);
console.log(typeof nome);
let idade = 45;
idade = 'RCS';
const nomeCompleto = 'Rodrigo Sertorio';
