"use strict";
// Função para calcular a área de um retângulo
function calcularArea(largura, altura) {
    return largura * altura;
}
// Variáveis de exemplo
let largura = 5;
let altura = 10;
// Calcular a área e mostrar no console
let area = calcularArea(largura, altura);
console.log(`A área do retângulo é: ${area}`);
