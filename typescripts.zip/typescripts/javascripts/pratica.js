"use strict";
let numero1 = 20;
let numero2 = 12;
let resultado = numero1 + numero2;
console.log(resultado);
