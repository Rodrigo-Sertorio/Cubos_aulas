const idade: number = 66

// menor que 18 -> Menor de idade
// maior de idade e menor que 65 anos -> Adulto
// acima de 65 anos -> Idoso

// if (idade < 18) {
// 	console.log('Menor de idade')
// } else {
// 	if (idade <= 65) {
// 		console.log('Adulto')
// 	} else {
// 		console.log('Idoso')
// 	}
// }

if (idade < 18) {
	console.log('Menor de idade')
} else if (idade <= 65) {
	console.log('Adulto')
} else {
	console.log('Idoso')
}