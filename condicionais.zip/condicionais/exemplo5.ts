const ativo: boolean = false

if (!ativo) {
	console.log('Verdadeiro')
} else {
	console.log('Falso')
}

// const nome = 'Guido'

// if (!nome) {
// 	console.log('O nome é obrigatório')
// } else {
// 	console.log(`Olá ${nome}`)
// }