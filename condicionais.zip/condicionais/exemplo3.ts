const idade = 17
const nome = 'Rodrigo'

let cor

// Truthiness
// Truthy -> Tudo que não é falsy
// Falsy -> false, 0, '', null, undefined, NaN

if (cor) {
	console.log('Verdadeiro')
} else {
	console.log('Falso')
}