const idade: number = 17

// validar se a condição é verdadeira
if (idade >= 18){
    //executar o que estiver entre o escopo
    console.log('é maior de idade')
}

console.log('Fim do Codigo')