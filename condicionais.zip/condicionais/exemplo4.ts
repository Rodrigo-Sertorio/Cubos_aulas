const numero = 9

const parOuImpar = numero % 2

const resultado = parOuImpar === 0 ? 'é par' : 'é impar'

console.log(resultado)

// if (resultado === 'par') {
// 	console.log('é par')
// } else {
// 	console.log('é impar')
// }

//ternário
// parOuImpar === 0 ? console.log('é par') : console.log('é impar')