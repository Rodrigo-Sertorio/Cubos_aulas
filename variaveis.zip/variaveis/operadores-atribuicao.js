// += Soma do valor da esquerda com o valor da direita
// -= Subtração do valor da esquerda com o valor da direita
// *= Multiplicação do valor da esquerda com o valor da direita
// /= Divisão do valor da esquerda com o valor da direita

let numero1 = 10

// numero1 = numero1 + 8
// numero1 += 8

// numero1 = numero1 - 5
// numero1 -= 5

// numero1 = numero1 * 3
// numero1 *= 3

// numero1 = numero1 / 2
// numero1 /= 2

console.log(numero1)