// 1. Declare uma variável multável
// 2. Armazene sua idade
// 3. Imprima o valor dessa variável
// 4. Reatribua um valor a essa variável que represente o dobro da sua idade
// 5. Imprima o novo valor dessa variável

let idade = 45

console.log(idade)

idade = idade * 2

console.log(idade)