// {
// 	let nome = 'Matheus'
// 	var idade = 20
// 	const cor = 'vermelho'
// }
// console.log(cor)

const nome = 'Rodrigo'
let idade = 45

{
	const nome = 'Ksren'
	console.log(nome, idade)
}

console.log(nome)