// 1. Dado o código abaixo, refatore usando template strings
// 2. Imprima a frase: Meu nome é xxxx e tenho xxx anos

let nome = 'Rodrigo C Sertorio'
let idade = 45

// let frase = 'Meu nome é ' + nome + ' e tenho ' + idade + ' anos' 
let frase = `Meu nome é ${nome} e tenho ${idade} anos`

console.log(frase)
