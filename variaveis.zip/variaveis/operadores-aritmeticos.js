// + Soma
// - Subtração
// * Multiplicação
// / Divisão

let numero1 = 7
let numero2 = 10

let soma = numero1 + numero2
let subtracao = numero1 - numero2
let multiplicacao = numero1 * numero2
let divisao = numero1 / numero2

console.log(divisao)