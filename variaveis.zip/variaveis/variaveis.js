var qualquercoisa = 'Rodrigo'
// var QualquerCoisa = 'Rodrigo'
// var qualquerCoisa = 'Rodrigo'
// var qualquer_coisa = 'Rodrigo'

console.log(qualquercoisa)

qualquercoisa = 123

console.log(qualquercoisa)

let nome = 'Rodrigo Sertorio'
let idade = 45

console.log(nome, idade)

nome = 'Matheus'
idade = 20

console.log(nome, idade)

const email = 'rodrigo09.sertorio@gmail.com'

console.log(email)