// let x = 1
// x++
// x++
// console.log(x)

// let y = 10
// y--
// y--
// console.log(y)

// let x = 1

// let y = ++x
// let y = --x

// console.log(x, y)