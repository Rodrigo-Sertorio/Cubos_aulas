let numero1 = 12
let numero2 = 4

let restoDivisao = numero1 % numero2

console.log(restoDivisao)