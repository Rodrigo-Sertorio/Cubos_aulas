// 1. Declare uma variável nome e uma idade
// 2. Imprima a frase: Meu nome é xxxx e tenho xxx anos

let nome = 'Rodrigo Sertorio'
let idade = 45  

let frase = 'Meu nome é ' + nome + ' e tenho ' + idade + ' anos' 

console.log(frase)
