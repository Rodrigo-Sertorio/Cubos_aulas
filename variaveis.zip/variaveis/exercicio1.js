// 1. Declare uma variável imutável
// 2. Armazene o nome da cidade em que você mora
// 3. Imprima o valor dessa variável

const cidade = 'Porto Alegre'

console.log(cidade)