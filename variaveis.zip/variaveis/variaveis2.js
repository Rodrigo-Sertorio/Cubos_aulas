// let nome
// console.log(nome)
// nome = 'Rodrigo Cardoso'
// console.log(nome)

// let numero
// {
// 	const idade = 45
// 	numero = idade
// }
// console.log(numero)

const email = 'sertorio'