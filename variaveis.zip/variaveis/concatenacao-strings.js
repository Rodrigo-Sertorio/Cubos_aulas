let nome = 'Rodrigo'
let sobrenome = 'Sertorio'

// Rodrigo Sertorio

// let nomecompleto = nome + ' ' + sobrenome
let nomecompleto = `Nome: ${nome}, Sobrenome: ${sobrenome}`

console.log(nomecompleto)