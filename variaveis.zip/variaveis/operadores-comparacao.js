// === Operador de comparação de igualdade
// !== Operador de comparação de diferença
// < Operador de comparação menor que
// > Operador de comparação maior que
// >= Operador de comparação maior ou igual
// <= Operador de comparação menor ou igual

let numero1 = 12
let numero2 = 15

let comparacao = numero1 === numero2
comparacao = numero1 !== numero2
comparacao = numero1 < numero2
comparacao = numero1 > numero2
comparacao = numero1 >= numero2
comparacao = numero1 <= numero2

console.log(comparacao)