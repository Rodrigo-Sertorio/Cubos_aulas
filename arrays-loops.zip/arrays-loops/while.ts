const listaFrutas: string[] = ['banana', 'abacaxi', 'maçã', 'pera', 'uva', 'manga']

let i = 0

while (i < listaFrutas.length) {
	console.log(listaFrutas[i])
	i++
}