// Faça um programa que conta quantas letras “r” existem 
// numa determinada palavra. Imprima o resultado na tela.

const palavra = 'Rodrigo'

let contador = 0

for (let letra of palavra) {
	if (letra === 'r') {
		contador += 1
	}
}

console.log(contador)