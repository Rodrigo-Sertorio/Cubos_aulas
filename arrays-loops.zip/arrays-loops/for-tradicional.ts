const listaFrutas = ['banana', 'abacaxi', 'maçã', 'pera', 'uva', 'manga']

for (let i = 0; i < listaFrutas.length; i++) {
	console.log(listaFrutas[i])
}

// let i = 0

// while (i < listaFrutas.length) {
// 	console.log(listaFrutas[i])
// 	i++
// }

// indice - condiçcão - o que fazer depois de executar o código
