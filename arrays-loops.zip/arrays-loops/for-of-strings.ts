const palavra = 'Rodrigo'

for (let letra of palavra) {
	console.log(letra)
}

