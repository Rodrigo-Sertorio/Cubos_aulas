// Faça um programa que conte de 10 até 0 
// (de trás pra frente mesmo).

let contagem = 10

while (contagem >= 0) {
	console.log(contagem)
	contagem--
}