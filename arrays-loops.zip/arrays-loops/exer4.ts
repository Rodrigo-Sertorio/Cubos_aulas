// Faça um programa que percorra uma lista de usuários 
// para encontrar o usuário "João". Caso encontre, imprima
// "Encontrado", caso contrário, imprima "Não encontrado"

const usuarios: string[] = ['Maria', 'Ana', 'João', 'Guido', 'Pedro']

let encontrado: boolean = false

for (let usuario of usuarios) {
	if (usuario === "João") {
		encontrado = true
		break
	}
}

if (encontrado) {
	console.log('Encontrado')
} else {
	console.log('Não Encontrado')
}