// Crie um array com 5 nomes de países
// Adicione um país ao fim da lista
// Imprima a lista na tela
// Altere o quinto país da lista para um novo país
// Imprima a lista na tela
// Imprima o último país da lista na tela
// Imprima o segundo país da lista na tela
// Imprima o país de índice 2 na tela

const paises = ['Brasil', 'Alemanha', 'Argentina', 'Chile', 'Uruguai']

paises[paises.length] = 'EUA'

console.log(paises)

paises[4] = 'Paraguai'

console.log(paises)

console.log(paises[paises.length - 1])

console.log(paises[1])

console.log(paises[2])