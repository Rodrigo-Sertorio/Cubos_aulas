const listaFrutas: string[] = ['banana', 'abacaxi', 'maçã', 'pera', 'uva', 'manga']

// for (let item of listaFrutas) {
// 	if (item === 'pera') {
// 		break
// 	}
// 	console.log(item)
// }

// for (let i = 0; i < listaFrutas.length; i++) {
// 	if (listaFrutas[i] === 'pera') {
// 		break
// 	}
// 	console.log(listaFrutas[i])
// }

// let i = 0

// while (i < listaFrutas.length) {
// 	if (listaFrutas[i] === 'pera') {
// 		break
// 	}
// 	console.log(listaFrutas[i])
// 	i++
// }

for (let item of listaFrutas) {
	if (item === 'pera' || item === 'uva') {
		continue
	}
	console.log(item)
}