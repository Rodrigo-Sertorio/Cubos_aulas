const rodrigo = 'Rodrigo'
const diego = 'Diego'
const karen = 'Karen'
const leandro = 'Leandro'

const listaUsuarios = ['Rodrigo', 'Diego', 'Karen', 'Leandro']
const numeros = [123, 456, 789]

console.log(listaUsuarios[0])
console.log(listaUsuarios[1])
console.log(listaUsuarios[2])
console.log(listaUsuarios[3])
console.log(listaUsuarios[4])
console.log(numeros[1])

console.log(listaUsuarios)

listaUsuarios[2] = 'Joana'
listaUsuarios[8] = 'Ana'

console.log(listaUsuarios)

console.log(listaUsuarios[4])