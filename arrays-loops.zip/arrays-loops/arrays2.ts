const frutas = ['banana', 'abacaxi', 'maçã', 'pera', 'uva', 'manga']

console.log(frutas.length)

frutas[6] = 'melão'

console.log(frutas.length)

// tamanho - 1
console.log(frutas)
let i = frutas.length - 1
console.log(frutas[i])

// o próximo indice a ser adicionado é sempre o tamanho do array
frutas[frutas.length] = 'abacate'

console.log(frutas)