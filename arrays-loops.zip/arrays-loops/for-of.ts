const listaFrutas: string[] = ['banana', 'abacaxi', 'maçã', 'pera', 'uva', 'manga']

// For tradicional
// for (let i = 0; i < listaFrutas.length; i++) {
// 	console.log(listaFrutas[i])
// }

// For of
for (let item of listaFrutas) {
	console.log(item)
}