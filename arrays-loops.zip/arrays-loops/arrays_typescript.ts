const listaFrutas: string[] = ['banana', 'abacaxi', 'maçã', 'pera', 'uva', 'manga']

listaFrutas[listaFrutas.length] = 'abacate'

const carros: string[] = []

carros[carros.length] = 'Gol'
carros[carros.length] = 'Pálio'
carros[carros.length] = 'Camaro'

console.log(carros)

const lista: number[] = []